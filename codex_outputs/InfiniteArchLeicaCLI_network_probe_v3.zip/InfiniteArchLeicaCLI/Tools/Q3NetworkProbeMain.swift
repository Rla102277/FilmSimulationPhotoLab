import Foundation

@main
struct Q3NetworkProbeMain {
    static let capturedClientID="89440BC7-DFC6-4929-A68D-8BD1C3C47BDF"

    static func main() async {
        let args=Array(CommandLine.arguments.dropFirst())
        let command=args.first ?? "help"
        let clientID=args.dropFirst().first ?? capturedClientID
        let q3=DirectQ3Transport()

        do {
            switch command {
            case "access":
                print("Q3 Wi-Fi access check (no camera settings or Looks are changed)")
                let report=try await q3.requestAccess(clientID:clientID)
                print(report)
                if report.finalResponse.contains("err_others_requesting") {
                    print("STOP: another access request is pending. Exit the Q3 connection mode before testing again.")
                } else if report.finalResponse.contains("err_critical") {
                    print("STOP: the access state machine needs to be reset by exiting the Q3 connection mode.")
                } else if report.finalResponse.contains("under_research_no_msg") {
                    print("STOP: this identity requires the missing encrypted pairing step; do not repeat this request.")
                }
            case "read":
                print("Direct read-only Leica Look table check (no HTTP access request)")
                print(try await q3.readOnlyLookProbe())
            case "help","--help","-h":
                print("""
                Usage:
                  q3-network-probe access [FOTOS-client-UUID]
                  q3-network-probe read

                access  Checks whether the Q3 grants the captured FOTOS client open access.
                read    Does not request access; it only tries PTP/IP operation 0x9033.

                Both commands are read-only with respect to camera settings and Leica Looks.
                """)
            default:
                print("Unknown command: \(command)")
                Foundation.exit(2)
            }
        } catch {
            print("ERROR: \(error.localizedDescription)")
            Foundation.exit(1)
        }
    }
}
