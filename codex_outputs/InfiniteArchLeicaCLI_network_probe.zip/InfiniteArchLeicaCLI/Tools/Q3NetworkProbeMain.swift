import Foundation

@main
struct Q3NetworkProbeMain {
    static let capturedClientID="89440BC7-DFC6-4929-A68D-8BD1C3C47BDF"

    static func main() async {
        let args=Array(CommandLine.arguments.dropFirst())
        let command=args.first ?? "help"
        let clientID=args.dropFirst().first ?? capturedClientID
        let q3=DirectQ3Transport()

        do {
            switch command {
            case "access":
                print("Q3 Wi-Fi access check (no camera settings or Looks are changed)")
                print(try await q3.requestAccess(clientID:clientID))
            case "read":
                print("Q3 access + read-only Leica Look table check")
                print(try await q3.authorizedLookProbe(clientID:clientID))
            case "help","--help","-h":
                print("""
                Usage:
                  q3-network-probe access [FOTOS-client-UUID]
                  q3-network-probe read [FOTOS-client-UUID]

                access  Checks whether the Q3 grants the captured FOTOS client open access.
                read    Requires open access, then reads Leica Look data with operation 0x9033.

                Both commands are read-only with respect to camera settings and Leica Looks.
                """)
            default:
                print("Unknown command: \(command)")
                Foundation.exit(2)
            }
        } catch {
            print("ERROR: \(error.localizedDescription)")
            Foundation.exit(1)
        }
    }
}
